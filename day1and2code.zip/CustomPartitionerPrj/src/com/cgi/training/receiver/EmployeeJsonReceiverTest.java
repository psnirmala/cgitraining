package com.cgi.training.receiver;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.cgi.training.domain.Employee;

public class EmployeeJsonReceiverTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties props=new Properties(); //kafka properties should be set in this object
		
		props.setProperty("bootstrap.servers", "localhost:9092"); //url of the kafka server
		props.setProperty("key.deserializer","org.apache.kafka.common.serialization.StringDeserializer"); //deserializer for the key
		props.setProperty("value.deserializer","com.cgi.training.deserializer.EmployeeJsonDeserializer"); //deserializer for the value
		props.setProperty("group.id", "demo-group");
		
		KafkaConsumer<String, Employee> consumer=new KafkaConsumer<String, Employee>(props);
		
		List<String> topicList=new ArrayList<String>();
		topicList.add("employeeTopic");
		
		consumer.subscribe(topicList);
		System.out.println("subscribed to employeeTopic");
		
		while(true){
			ConsumerRecords<String, Employee> records=consumer.poll(Duration.ofSeconds(3));
			for(ConsumerRecord<String, Employee> record:records){
				System.out.println("received message:" +record.key());
				System.out.println("Employee Data from partition "+record.partition());
				Employee e=record.value();
				System.out.println(e.getId()+"\t"+e.getName()+"\t"+e.getDesignation());
			}
			
		}
		
		

	}

}
