package com.cgi.training.partitioner;

import java.util.Map;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

import com.cgi.training.domain.Employee;


/*
 In this example we are assuming that Developers will go to partition 0
 Accountants will go to partition 1
 System Admin will go to partition 2
 All other will go to partition 3
 */
public class EmployeePartitioner implements Partitioner{

	@Override
	public void configure(Map<String, ?> configs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int partition(String topic, Object key, byte[] keyBytes,
			Object value, byte[] valueBytes, Cluster cluster) {
		// TODO Auto-generated method stub
		System.out.println("invoking partitioner");
		Employee e=(Employee)value;
		int partition=3;
		String designation=e.getDesignation();
		if(designation.equals("Accountant")){
			partition=0;
		}
		else if(designation.equals("Developer")){
			partition=1;
		}
		else if(designation.equals("Sys Admin")){
			partition=2;
		}
		return partition;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

}
