package com.cgi.training.sender;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.cgi.training.domain.Employee;

public class EmployeeJsonSenderTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties props=new Properties(); //kafka properties should be set in this object
		
		props.setProperty("bootstrap.servers", "localhost:9092"); //url of the kafka server
		props.setProperty("key.serializer","org.apache.kafka.common.serialization.StringSerializer"); //serializer for the key
		props.setProperty("value.serializer","com.cgi.training.serializer.EmployeeJsonSerializer"); //serializer for the value
		props.setProperty("partitioner.class", "com.cgi.training.partitioner.EmployeePartitioner");
		KafkaProducer<String,Employee> producer=new KafkaProducer<String, Employee>(props);
		String topicName="employeeTopic";
		List<Employee> list=new ArrayList<Employee>();
		list.add(new Employee(1001, "Rajiv", "Developer"));
		//list.add(new Employee(1002, "Arun", "Developer"));
		list.add(new Employee(1003, "Deva", "Accountant"));
		list.add(new Employee(1004, "Arjun", "Sys Admin"));
		list.add(new Employee(1005, "Amar", "Sys Admin"));
		list.add(new Employee(1006, "Priya", "Architect"));
		
		for(Employee e:list){
		ProducerRecord<String, Employee> record=
				new ProducerRecord<String, Employee>(topicName, e.getDesignation(),e);
		producer.send(record,new Callback() {
			
			@Override
			public void onCompletion(RecordMetadata metadata, Exception exception) {
				// TODO Auto-generated method stub
				System.out.println("employee with id "+record.value().getId()+" and designation "+record.value().getDesignation()+" published to "+
				metadata.partition()+" at offset "+metadata.offset());
			}
		});
		}
		
		System.out.println("messages sent");
		producer.close();
		

	}

}
