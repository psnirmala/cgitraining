package com.cgi.training.marshaller;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.cgi.training.domain.Employee;

public class EmployeeMarshallerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			JAXBContext context=JAXBContext.newInstance(Employee.class);
			Marshaller marshaller=context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			Employee e=new Employee(1001, "Akash", "Accountant");
			marshaller.marshal(e, new FileOutputStream("emp.xml"));
			System.out.println("marshalling done");
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}

}
