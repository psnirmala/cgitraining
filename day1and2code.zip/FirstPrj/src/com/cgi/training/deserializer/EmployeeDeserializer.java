package com.cgi.training.deserializer;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.kafka.common.serialization.Deserializer;

import com.cgi.training.domain.Employee;

public class EmployeeDeserializer implements Deserializer<Employee>{

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		// TODO Auto-generated method stub
		
	}

	
	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public Employee deserialize(String topic, byte[] data) {
		// TODO Auto-generated method stub
		System.out.println("within deserialize");
	Employee emp=null;
	String xmlContent=new String(data);
	try {
		JAXBContext context=JAXBContext.newInstance(Employee.class);
		Unmarshaller unmarshaller=context.createUnmarshaller();
		emp=(Employee) unmarshaller.unmarshal(new StringReader(xmlContent));
	} catch (JAXBException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return emp;
	}

}
