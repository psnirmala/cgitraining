package com.cgi.training.serializer;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.StringWriter;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.kafka.common.serialization.Serializer;

import com.cgi.training.domain.Employee;

public class EmployeeSerializer implements Serializer<Employee>{

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public byte[] serialize(String topic, Employee data) {
		// TODO Auto-generated method stub
		byte[] array=null;
		try {
			JAXBContext context=JAXBContext.newInstance(Employee.class);
			Marshaller marshaller=context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			Employee e=new Employee(1001, "Akash", "Accountant");
			StringWriter writer=new StringWriter();
			marshaller.marshal(e, writer);
			String xmlContent=writer.toString();
			//System.out.println("serialized to "+xmlContent);
			return xmlContent.getBytes();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return array;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

}
