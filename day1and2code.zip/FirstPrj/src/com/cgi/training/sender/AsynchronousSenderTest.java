package com.cgi.training.sender;

import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

public class AsynchronousSenderTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties props=new Properties(); //kafka properties should be set in this object
		
		props.setProperty("bootstrap.servers", "localhost:9092"); //url of the kafka server
		props.setProperty("key.serializer","org.apache.kafka.common.serialization.StringSerializer"); //serializer for the key
		props.setProperty("value.serializer","org.apache.kafka.common.serialization.StringSerializer"); //serializer for the value
		KafkaProducer<String, String> producer=new KafkaProducer<String, String>(props);
		String topicName="topic1";
		for(int i=1;i<=20;i++){
		ProducerRecord<String, String> record=new ProducerRecord<String, String>(topicName, "message-test","This is a test message "+i);
		producer.send(record, new Callback() {
			
			@Override
			public void onCompletion(RecordMetadata metadata, Exception exception) {
				// TODO Auto-generated method stub
			if(exception==null){
				System.out.println("message successfully published to "+metadata.partition());
			}
			else{
				System.out.println(exception.getMessage());
			}
			}
		});
		System.out.println("message "+i+" sent");
		
		}
		
		producer.close();
		

	}

}
