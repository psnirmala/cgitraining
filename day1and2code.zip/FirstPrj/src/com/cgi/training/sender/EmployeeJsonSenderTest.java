package com.cgi.training.sender;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.cgi.training.domain.Employee;

public class EmployeeJsonSenderTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties props=new Properties(); //kafka properties should be set in this object
		
		props.setProperty("bootstrap.servers", "localhost:9092"); //url of the kafka server
		props.setProperty("key.serializer","org.apache.kafka.common.serialization.StringSerializer"); //serializer for the key
		props.setProperty("value.serializer","com.cgi.training.serializer.EmployeeJsonSerializer"); //serializer for the value
		KafkaProducer<String,Employee> producer=new KafkaProducer<String, Employee>(props);
		String topicName="topic1";
		ProducerRecord<String, Employee> record=
				new ProducerRecord<String, Employee>(topicName, "employee-1",new Employee(1991, "Arun", "Developer"));
		producer.send(record);
		System.out.println("message sent");
		producer.close();
		

	}

}
