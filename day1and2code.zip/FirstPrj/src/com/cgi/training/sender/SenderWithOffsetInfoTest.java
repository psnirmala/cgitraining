package com.cgi.training.sender;

import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

public class SenderWithOffsetInfoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties props=new Properties(); //kafka properties should be set in this object
		
		props.setProperty("bootstrap.servers", "localhost:9092"); //url of the kafka server
		props.setProperty("key.serializer","org.apache.kafka.common.serialization.StringSerializer"); //serializer for the key
		props.setProperty("value.serializer","org.apache.kafka.common.serialization.StringSerializer"); //serializer for the value
		KafkaProducer<String, String> producer=new KafkaProducer<String, String>(props);
		String topicName="employeeTopic";
		for(int i=1;i<=50;i++){
		System.out.println("sending message "+1);	
		ProducerRecord<String, String> record=new ProducerRecord<String, String>(topicName, "message: "+i,"This is a test message "+i);
		producer.send(record,new Callback() {
			
			@Override
			public void onCompletion(RecordMetadata metadata, Exception exception) {
				// TODO Auto-generated method stub
				System.out.println("data is published to partition number "+metadata.partition()+" at offset:  "+metadata.offset());
			}
		});
		}
		System.out.println("messages sent");
		producer.close();
		

	}

}
